import os
from flask import Blueprint, jsonify, request, current_app, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from datetime import datetime
from src.models.user import User, Resume, ResumeSection, WorkExperience, Education, Skill, db
from src.utils.resume_parser import ResumeParser

resume_bp = Blueprint('resume', __name__)

# Configure upload settings
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'doc', 'txt'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_upload_folder():
    """Create upload folder if it doesn't exist"""
    upload_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), UPLOAD_FOLDER)
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)
    return upload_path

@resume_bp.route('/resumes', methods=['GET'])
@jwt_required()
def get_resumes():
    """Get all resumes for the authenticated user"""
    try:
        user_id = get_jwt_identity()
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        sort_by = request.args.get('sort_by', 'created_at')
        order = request.args.get('order', 'desc')
        
        # Build query
        query = Resume.query.filter_by(user_id=user_id, is_active=True)
        
        # Apply sorting
        if hasattr(Resume, sort_by):
            if order.lower() == 'desc':
                query = query.order_by(getattr(Resume, sort_by).desc())
            else:
                query = query.order_by(getattr(Resume, sort_by))
        
        # Paginate results
        resumes = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'resumes': [resume.to_dict() for resume in resumes.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': resumes.total,
                'pages': resumes.pages,
                'has_next': resumes.has_next,
                'has_prev': resumes.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@resume_bp.route("/resumes/upload", methods=["POST"])
# @jwt_required() # Temporarily disable for debugging
def upload_resume():
    """Upload and parse a new resume file"""
    try:
        # user_id = get_jwt_identity() # Temporarily disable
        print("\n--- Incoming Upload Request ---")
        print(f"Headers: {request.headers}")
        print(f"Form Data: {request.form}")
        print(f"Files: {request.files}")
        # print(f"JWT Identity: {user_id}")
        print("-------------------------------")

        user_id = 1 # Temporary user_id for testing without JWT

        # Check if file is present
        if "file" not in request.files:
            print("Error: No file provided")
            return jsonify({"error": "No file provided"}), 400

        file = request.files["file"]
        title = request.form.get("title", "")

        if file.filename == "":
            print("Error: No file selected")
            return jsonify({"error": "No file selected"}), 400

        if not allowed_file(file.filename):
            print(f"Error: File type not allowed: {file.filename}")
            return jsonify({"error": "File type not allowed"}), 400

        # Create upload folder
        upload_path = create_upload_folder()

        # Generate secure filename
        filename = secure_filename(file.filename)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"{user_id}_{timestamp}_{filename}"
        file_path = os.path.join(upload_path, filename)

        # Save file
        file.save(file_path)
        print(f"File saved to: {file_path}")

        # Parse resume
        parser = ResumeParser()
        parsed_data = parser.parse_resume(file_path)
        print(f"Parsed Data: {parsed_data}")

        # Create resume record
        resume = Resume(
            user_id=user_id,
            title=title or ("Resume - " + datetime.utcnow().strftime("%Y-%m-%d")),
            original_filename=file.filename,
            file_path=file_path,
            parsed_content=parsed_data["cleaned_text"]
        )

        db.session.add(resume)
        db.session.flush()  # Get the resume ID

        # Create resume sections
        for section_type, content_list in parsed_data["sections"].items():
            if content_list:
                section = ResumeSection(
                    resume_id=resume.id,
                    section_type=section_type,
                    section_title=section_type.replace("_", " ").title(),
                    content="\n".join(content_list)
                )
                db.session.add(section)

        # Create work experience entries
        for i, exp in enumerate(parsed_data["work_experience"]):
            work_exp = WorkExperience(
                resume_id=resume.id,
                description=exp["context"],
                display_order=i
            )
            db.session.add(work_exp)

        # Create education entries
        for i, edu in enumerate(parsed_data["education"]):
            education = Education(
                resume_id=resume.id,
                description=edu["text"],
                display_order=i
            )
            db.session.add(education)

        # Create skill entries
        for i, skill_data in enumerate(parsed_data["skills"]):
            skill = Skill(
                resume_id=resume.id,
                skill_name=skill_data["name"],
                skill_category=skill_data["category"],
                display_order=i
            )
            db.session.add(skill)

        db.session.commit()

        print("Success: Resume uploaded and parsed successfully")
        return jsonify({
            "message": "Resume uploaded and parsed successfully",
            "resume": resume.to_dict(),
            "parsed_data": {
                "contact_info": parsed_data["contact_info"],
                "sections_count": len(parsed_data["sections"]),
                "work_experience_count": len(parsed_data["work_experience"]),
                "education_count": len(parsed_data["education"]),
                "skills_count": len(parsed_data["skills"])
            }
        }), 201

    except Exception as e:
        db.session.rollback()
        # Clean up uploaded file on error
        if "file_path" in locals() and os.path.exists(file_path):
            os.remove(file_path)
        print(f"Error during upload: {e}")
        return jsonify({"error": str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>', methods=['GET'])
@jwt_required()
def get_resume(resume_id):
    """Get specific resume with all sections"""
    try:
        user_id = get_jwt_identity()
        
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        # Get all related data
        sections = [section.to_dict() for section in resume.sections]
        work_experiences = [exp.to_dict() for exp in resume.work_experiences]
        educations = [edu.to_dict() for edu in resume.educations]
        skills = [skill.to_dict() for skill in resume.skills]
        
        return jsonify({
            'resume': resume.to_dict(),
            'sections': sections,
            'work_experiences': work_experiences,
            'educations': educations,
            'skills': skills
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>', methods=['PUT'])
@jwt_required()
def update_resume(resume_id):
    """Update resume metadata"""
    try:
        user_id = get_jwt_identity()
        
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        if 'title' in data:
            resume.title = data['title']
        
        resume.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Resume updated successfully',
            'resume': resume.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>', methods=['DELETE'])
@jwt_required()
def delete_resume(resume_id):
    """Delete resume and all associated data"""
    try:
        user_id = get_jwt_identity()
        
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        # Soft delete
        resume.is_active = False
        resume.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Clean up file
        if resume.file_path and os.path.exists(resume.file_path):
            try:
                os.remove(resume.file_path)
            except Exception as e:
                print(f"Warning: Could not delete file {resume.file_path}: {e}")
        
        return jsonify({'message': 'Resume deleted successfully'}), 204
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Resume Sections endpoints
@resume_bp.route('/resumes/<int:resume_id>/sections', methods=['GET'])
@jwt_required()
def get_resume_sections(resume_id):
    """Get all sections for a specific resume"""
    try:
        user_id = get_jwt_identity()
        
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        section_type = request.args.get('section_type')
        
        query = ResumeSection.query.filter_by(resume_id=resume_id)
        if section_type:
            query = query.filter_by(section_type=section_type)
        
        sections = query.order_by(ResumeSection.display_order).all()
        
        return jsonify({
            'sections': [section.to_dict() for section in sections]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>/sections', methods=['POST'])
@jwt_required()
def create_resume_section(resume_id):
    """Create a new resume section"""
    try:
        user_id = get_jwt_identity()
        
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        if not data.get('section_type'):
            return jsonify({'error': 'section_type is required'}), 400
        
        section = ResumeSection(
            resume_id=resume_id,
            section_type=data['section_type'],
            section_title=data.get('section_title', ''),
            content=data.get('content', ''),
            display_order=data.get('display_order', 0)
        )
        
        db.session.add(section)
        db.session.commit()
        
        return jsonify({
            'message': 'Section created successfully',
            'section': section.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>/sections/<int:section_id>', methods=['PUT'])
@jwt_required()
def update_resume_section(resume_id, section_id):
    """Update a specific resume section"""
    try:
        user_id = get_jwt_identity()
        
        # Verify resume ownership
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        section = ResumeSection.query.filter_by(
            id=section_id, 
            resume_id=resume_id
        ).first()
        
        if not section:
            return jsonify({'error': 'Section not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        if 'section_title' in data:
            section.section_title = data['section_title']
        if 'content' in data:
            section.content = data['content']
        if 'display_order' in data:
            section.display_order = data['display_order']
        
        section.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Section updated successfully',
            'section': section.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/resumes/<int:resume_id>/sections/<int:section_id>', methods=['DELETE'])
@jwt_required()
def delete_resume_section(resume_id, section_id):
    """Delete a specific resume section"""
    try:
        user_id = get_jwt_identity()
        
        # Verify resume ownership
        resume = Resume.query.filter_by(
            id=resume_id, 
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        section = ResumeSection.query.filter_by(
            id=section_id, 
            resume_id=resume_id
        ).first()
        
        if not section:
            return jsonify({'error': 'Section not found'}), 404
        
        db.session.delete(section)
        db.session.commit()
        
        return jsonify({'message': 'Section deleted successfully'}), 204
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500



@resume_bp.route('/<int:resume_id>/download', methods=['GET'])
@jwt_required()
def download_resume_pdf(resume_id):
    """Download resume as PDF"""
    try:
        current_user_id = get_jwt_identity()
        
        # Get resume and verify ownership
        resume = Resume.query.filter_by(id=resume_id, user_id=current_user_id).first()
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        # Prepare resume data for PDF generation
        resume_data = {
            'user': resume.user.to_dict(),
            'sections': [section.to_dict() for section in resume.sections],
            'work_experiences': [exp.to_dict() for exp in resume.work_experiences],
            'educations': [edu.to_dict() for edu in resume.educations],
            'skills': [skill.to_dict() for skill in resume.skills]
        }
        
        # Generate PDF
        from ..utils.pdf_generator import generate_resume_pdf
        
        # Create temporary file path
        pdf_filename = f"resume_{resume_id}_{current_user_id}.pdf"
        pdf_path = os.path.join(app.config.get('UPLOAD_FOLDER', '/tmp'), pdf_filename)
        
        # Generate the PDF
        success = generate_resume_pdf(resume_data, pdf_path)
        
        if not success:
            return jsonify({'error': 'Failed to generate PDF'}), 500
        
        # Return the PDF file
        return send_file(
            pdf_path,
            as_attachment=True,
            download_name=f"{resume.title.replace(' ', '_')}.pdf",
            mimetype='application/pdf'
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@resume_bp.route('/<int:resume_id>/preview', methods=['GET'])
@jwt_required()
def preview_resume_pdf(resume_id):
    """Preview resume as PDF in browser"""
    try:
        current_user_id = get_jwt_identity()
        
        # Get resume and verify ownership
        resume = Resume.query.filter_by(id=resume_id, user_id=current_user_id).first()
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        # Prepare resume data for PDF generation
        resume_data = {
            'user': resume.user.to_dict(),
            'sections': [section.to_dict() for section in resume.sections],
            'work_experiences': [exp.to_dict() for exp in resume.work_experiences],
            'educations': [edu.to_dict() for edu in resume.educations],
            'skills': [skill.to_dict() for skill in resume.skills]
        }
        
        # Generate PDF
        from ..utils.pdf_generator import generate_resume_pdf
        
        # Create temporary file path
        pdf_filename = f"preview_{resume_id}_{current_user_id}.pdf"
        pdf_path = os.path.join(app.config.get('UPLOAD_FOLDER', '/tmp'), pdf_filename)
        
        # Generate the PDF
        success = generate_resume_pdf(resume_data, pdf_path)
        
        if not success:
            return jsonify({'error': 'Failed to generate PDF'}), 500
        
        # Return the PDF file for preview
        return send_file(
            pdf_path,
            mimetype='application/pdf'
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

