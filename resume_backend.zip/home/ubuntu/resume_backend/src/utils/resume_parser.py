import os
import re
import PyPDF2
import pdfplumber
from docx import Document
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ResumeParser:
    """Comprehensive resume parsing utility for extracting text from PDF and DOCX files"""
    
    def __init__(self):
        self.supported_formats = ['.pdf', '.docx', '.doc', '.txt']
        
    def parse_resume(self, file_path):
        """
        Parse resume file and extract comprehensive text content
        
        Args:
            file_path (str): Path to the resume file
            
        Returns:
            dict: Parsed resume data with sections and raw text
        """
        try:
            file_extension = os.path.splitext(file_path)[1].lower()
            
            if file_extension == '.pdf':
                return self._parse_pdf(file_path)
            elif file_extension in ['.docx', '.doc']:
                return self._parse_docx(file_path)
            elif file_extension == '.txt':
                return self._parse_txt(file_path)
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
                
        except Exception as e:
            logger.error(f"Error parsing resume: {str(e)}")
            raise
    
    def _parse_pdf(self, file_path):
        """Parse PDF file using multiple methods for comprehensive text extraction"""
        text_content = ""
        
        # Method 1: Try PyPDF2 first
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_content += page_text + "\n"
            logger.info(f"PyPDF2 extracted {len(text_content.strip())} characters.")
        except Exception as e:
            logger.warning(f"PyPDF2 extraction failed: {str(e)}")
        
        # Method 2: Try pdfplumber for better text extraction
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_content += page_text + "\n"
            logger.info(f"pdfplumber extracted {len(text_content.strip())} characters.")
        except Exception as e:
            logger.warning(f"pdfplumber extraction failed: {str(e)}")
        
        if not text_content.strip():
            raise ValueError("Could not extract text from PDF file")
        
        return self._process_extracted_text(text_content)
    
    def _parse_docx(self, file_path):
        """Parse DOCX file and extract text content"""
        try:
            doc = Document(file_path)
            text_content = ""
            
            # Extract text from paragraphs
            for paragraph in doc.paragraphs:
                text_content += paragraph.text + "\n"
            
            # Extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text_content += cell.text + " "
                    text_content += "\n"
            
            if not text_content.strip():
                raise ValueError("Could not extract text from DOCX file")
            
            return self._process_extracted_text(text_content)
            
        except Exception as e:
            logger.error(f"Error parsing DOCX file: {str(e)}")
            raise
    
    def _parse_txt(self, file_path):
        """Parse plain text file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                text_content = file.read()
            
            return self._process_extracted_text(text_content)
            
        except Exception as e:
            logger.error(f"Error parsing TXT file: {str(e)}")
            raise
    
    def _process_extracted_text(self, raw_text):
        """Process extracted text and identify sections"""
        # Clean and normalize text
        cleaned_text = self._clean_text(raw_text)
        
        # Identify sections
        sections = self._identify_sections(cleaned_text)
        
        # Extract structured data
        contact_info = self._extract_contact_info(cleaned_text)
        work_experience = self._extract_work_experience(cleaned_text)
        education = self._extract_education(cleaned_text)
        skills = self._extract_skills(cleaned_text)
        
        return {
            'raw_text': raw_text,
            'cleaned_text': cleaned_text,
            'sections': sections,
            'contact_info': contact_info,
            'work_experience': work_experience,
            'education': education,
            'skills': skills,
            'parsed_at': datetime.utcnow().isoformat()
        }
    
    def _clean_text(self, text):
        """Clean and normalize extracted text"""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep important punctuation
        text = re.sub(r'[^\w\s\-\.\@\(\)\,\:\;\/\&\+\#]', '', text)
        
        # Normalize line breaks
        text = re.sub(r'\n\s*\n', '\n\n', text)
        
        return text.strip()
    
    def _identify_sections(self, text):
        """Identify different sections in the resume"""
        sections = {}
        
        # Common section headers
        section_patterns = {
            'summary': r'(?i)(summary|profile|objective|about|overview)',
            'experience': r'(?i)(experience|employment|work\s+history|professional\s+experience)',
            'education': r'(?i)(education|academic|qualifications|degrees)',
            'skills': r'(?i)(skills|competencies|technical\s+skills|core\s+competencies)',
            'certifications': r'(?i)(certifications?|certificates?|licenses?)',
            'projects': r'(?i)(projects?|portfolio)',
            'achievements': r'(?i)(achievements?|accomplishments?|awards?)',
            'references': r'(?i)(references?)',
            'languages': r'(?i)(languages?|linguistic)',
            'interests': r'(?i)(interests?|hobbies|activities)'
        }
        
        lines = text.split('\n')
        current_section = 'other'
        section_content = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Check if line is a section header
            section_found = False
            for section_name, pattern in section_patterns.items():
                if re.search(pattern, line) and len(line) < 50:  # Likely a header
                    # Save previous section
                    if section_content:
                        if current_section not in sections:
                            sections[current_section] = []
                        sections[current_section].extend(section_content)
                    
                    # Start new section
                    current_section = section_name
                    section_content = []
                    section_found = True
                    break
            
            if not section_found:
                section_content.append(line)
        
        # Save last section
        if section_content:
            if current_section not in sections:
                sections[current_section] = []
            sections[current_section].extend(section_content)
        
        return sections
    
    def _extract_contact_info(self, text):
        """Extract contact information from text"""
        contact_info = {}
        
        # Email pattern
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        if emails:
            contact_info['email'] = emails[0]
        
        # Phone pattern
        phone_pattern = r'(\+?1?[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})'
        phones = re.findall(phone_pattern, text)
        if phones:
            contact_info['phone'] = ''.join(phones[0])
        
        # LinkedIn pattern
        linkedin_pattern = r'(?i)linkedin\.com/in/([a-zA-Z0-9-]+)'
        linkedin = re.search(linkedin_pattern, text)
        if linkedin:
            contact_info['linkedin'] = f"linkedin.com/in/{linkedin.group(1)}"
        
        # GitHub pattern
        github_pattern = r'(?i)github\.com/([a-zA-Z0-9-]+)'
        github = re.search(github_pattern, text)
        if github:
            contact_info['github'] = f"github.com/{github.group(1)}"
        
        return contact_info
    
    def _extract_work_experience(self, text):
        """Extract work experience information"""
        experiences = []
        
        # Look for date patterns that might indicate work experience
        date_pattern = r'(\d{4})\s*[-–]\s*(\d{4}|present|current)'
        company_patterns = [
            r'(?i)(company|corporation|corp|inc|llc|ltd|technologies|tech|systems|solutions)',
            r'(?i)(software|consulting|marketing|finance|healthcare|education)'
        ]
        
        lines = text.split('\n')
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Look for date ranges
            date_match = re.search(date_pattern, line, re.IGNORECASE)
            if date_match:
                # Look for company and position in nearby lines
                context_lines = lines[max(0, i-2):min(len(lines), i+3)]
                context_text = ' '.join(context_lines)
                
                experience = {
                    'date_range': date_match.group(0),
                    'context': context_text.strip()
                }
                experiences.append(experience)
        
        return experiences
    
    def _extract_education(self, text):
        """Extract education information"""
        education = []
        
        # Degree patterns
        degree_patterns = [
            r'(?i)(bachelor|master|phd|doctorate|associate|diploma|certificate)',
            r'(?i)(b\.?s\.?|m\.?s\.?|b\.?a\.?|m\.?a\.?|ph\.?d\.?)',
            r'(?i)(degree|graduation|graduated)'
        ]
        
        # Institution patterns
        institution_patterns = [
            r'(?i)(university|college|institute|school|academy)',
            r'(?i)(state|national|international|technical)'
        ]
        
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            
            # Check for degree keywords
            for pattern in degree_patterns:
                if re.search(pattern, line):
                    education.append({
                        'text': line,
                        'type': 'degree_mention'
                    })
                    break
            
            # Check for institution keywords
            for pattern in institution_patterns:
                if re.search(pattern, line):
                    education.append({
                        'text': line,
                        'type': 'institution_mention'
                    })
                    break
        
        return education
    
    def _extract_skills(self, text):
        """Extract skills information"""
        skills = []
        
        # Common technical skills
        technical_skills = [
            'python', 'java', 'javascript', 'react', 'angular', 'vue', 'node',
            'sql', 'mysql', 'postgresql', 'mongodb', 'redis',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes',
            'git', 'github', 'gitlab', 'jenkins', 'ci/cd',
            'html', 'css', 'bootstrap', 'tailwind',
            'flask', 'django', 'express', 'spring',
            'machine learning', 'ai', 'data science', 'analytics'
        ]
        
        # Soft skills
        soft_skills = [
            'leadership', 'communication', 'teamwork', 'problem solving',
            'project management', 'analytical', 'creative', 'adaptable'
        ]
        
        text_lower = text.lower()
        
        # Find technical skills
        for skill in technical_skills:
            if skill.lower() in text_lower:
                skills.append({
                    'name': skill,
                    'category': 'technical'
                })
        
        # Find soft skills
        for skill in soft_skills:
            if skill.lower() in text_lower:
                skills.append({
                    'name': skill,
                    'category': 'soft'
                })
        
        return skills

