import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  FileText, 
  Upload, 
  Edit3, 
  Download, 
  Zap, 
  Shield, 
  Users, 
  Star,
  CheckCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react'

const LandingPage = () => {
  const features = [
    {
      icon: <Upload className="h-8 w-8 text-primary" />,
      title: "Smart Upload",
      description: "Upload your existing resume in PDF, DOCX, or TXT format and our AI will parse every detail automatically."
    },
    {
      icon: <Edit3 className="h-8 w-8 text-primary" />,
      title: "Intelligent Editing",
      description: "Edit every section with our intuitive interface. Add, remove, or modify content with real-time preview."
    },
    {
      icon: <Download className="h-8 w-8 text-primary" />,
      title: "Professional PDF",
      description: "Generate beautiful, ATS-friendly PDF resumes with multiple professional templates to choose from."
    },
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: "Lightning Fast",
      description: "Create and update your resume in minutes, not hours. Our streamlined process saves you valuable time."
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Secure & Private",
      description: "Your data is encrypted and secure. We never share your personal information with third parties."
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Multiple Resumes",
      description: "Create and manage multiple resume versions for different job applications and career paths."
    }
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Software Engineer",
      content: "cvZen helped me land my dream job at a tech startup. The parsing was incredibly accurate!",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "Marketing Manager",
      content: "I love how easy it is to customize my resume for different positions. The templates are professional and modern.",
      rating: 5
    },
    {
      name: "Emily Rodriguez",
      role: "Data Scientist",
      content: "The AI parsing saved me hours of manual data entry. Highly recommend for anyone job hunting!",
      rating: 5
    }
  ]

  const benefits = [
    "Parse any resume format with 99% accuracy",
    "Professional templates designed by experts",
    "ATS-optimized for better job application success",
    "Real-time editing with instant preview",
    "Secure cloud storage for all your resumes",
    "Export to multiple formats (PDF, DOCX)",
    "Mobile-responsive design for editing on-the-go",
    "24/7 customer support"
  ]

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <img src="/cvzen-logo.png" alt="cvZen" className="h-8 w-auto" />
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="ghost">Sign In</Button>
              </Link>
              <Link to="/register">
                <Button>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Sparkles className="h-4 w-4 mr-1" />
              AI-Powered Resume Builder
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Create Professional Resumes with 
              <span className="text-primary"> cvZen</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Upload your existing resume and let our AI parse every detail. Edit with ease, 
              choose from professional templates, and download as a polished PDF ready for any job application.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="text-lg px-8 py-6">
                  Start Building Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8 py-6">
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Everything You Need to Build the Perfect Resume
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our comprehensive platform handles every aspect of resume creation, 
              from intelligent parsing to professional formatting.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                Why Choose cvZen?
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Join thousands of professionals who have successfully landed their dream jobs 
                using our advanced resume building platform.
              </p>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-base">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl p-8 h-96 flex items-center justify-center">
                <div className="text-center">
                  <FileText className="h-24 w-24 text-primary mx-auto mb-4" />
                  <h3 className="text-2xl font-semibold mb-2">Professional Results</h3>
                  <p className="text-muted-foreground">
                    Beautiful, ATS-optimized resumes that get noticed by recruiters with cvZen
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Loved by Professionals Worldwide
            </h2>
            <p className="text-xl text-muted-foreground">
              See what our users have to say about their experience
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center space-x-1 mb-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <CardDescription className="text-base italic">
                    "{testimonial.content}"
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Ready to Build Your Perfect Resume?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join thousands of professionals who have already transformed their careers. 
              Start building your professional resume today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="text-lg px-8 py-6">
                  Get Started for Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/login">
                <Button size="lg" variant="outline" className="text-lg px-8 py-6">
                  Sign In
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <img src="/cvzen-logo.png" alt="cvZen" className="h-6 w-auto" />
            </div>
            <div className="text-sm text-muted-foreground">
              © 2025 cvZen. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage

