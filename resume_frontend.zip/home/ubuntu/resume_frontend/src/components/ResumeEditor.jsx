import React, { useState, useEffect } from 'react'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useAuth } from '../App'
import { 
  ArrowLeft, 
  Save, 
  Download, 
  Eye, 
  Plus, 
  Trash2, 
  Edit3,
  FileText,
  User,
  Briefcase,
  GraduationCap,
  Award,
  Loader2
} from 'lucide-react'

const ResumeEditor = () => {
  const { id } = useParams()
  const { token } = useAuth()
  const navigate = useNavigate()
  
  const [resume, setResume] = useState(null)
  const [sections, setSections] = useState([])
  const [workExperience, setWorkExperience] = useState([])
  const [education, setEducation] = useState([])
  const [skills, setSkills] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    fetchResumeData()
  }, [id])

  const fetchResumeData = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/resumes/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setResume(data.resume)
        setSections(data.sections || [])
        setWorkExperience(data.work_experiences || [])
        setEducation(data.educations || [])
        setSkills(data.skills || [])
      } else {
        setError('Failed to load resume data')
      }
    } catch (error) {
      setError('Network error occurred')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      // Save resume title
      const response = await fetch(`http://localhost:5000/api/resumes/${id}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: resume.title
        })
      })
      
      if (response.ok) {
        // Show success message
        alert('Resume saved successfully!')
      } else {
        setError('Failed to save resume')
      }
    } catch (error) {
      setError('Network error occurred')
    } finally {
      setSaving(false)
    }
  }

  const handleDownloadPDF = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/resumes/${id}/pdf`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `${resume.title}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
      } else {
        setError('Failed to generate PDF')
      }
    } catch (error) {
      setError('Network error occurred')
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return ''
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!resume) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="text-center py-8">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Resume Not Found</h3>
            <p className="text-muted-foreground mb-4">
              The resume you're looking for doesn't exist or you don't have access to it.
            </p>
            <Link to="/dashboard">
              <Button>Back to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link to="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Edit3 className="h-6 w-6 text-primary" />
                <span className="text-lg font-semibold">Resume Editor</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
              <Button size="sm" onClick={handleSave} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Resume Header */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <Input
                  value={resume.title}
                  onChange={(e) => setResume({...resume, title: e.target.value})}
                  className="text-2xl font-bold border-none p-0 h-auto bg-transparent"
                  placeholder="Resume Title"
                />
                <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                  <span>Created: {formatDate(resume.created_at)}</span>
                  <span>Updated: {formatDate(resume.updated_at)}</span>
                  <Badge variant="secondary">Version {resume.version}</Badge>
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Editor Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <Eye className="h-4 w-4" />
              <span>Overview</span>
            </TabsTrigger>
            <TabsTrigger value="sections" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Sections</span>
            </TabsTrigger>
            <TabsTrigger value="experience" className="flex items-center space-x-2">
              <Briefcase className="h-4 w-4" />
              <span>Experience</span>
            </TabsTrigger>
            <TabsTrigger value="education" className="flex items-center space-x-2">
              <GraduationCap className="h-4 w-4" />
              <span>Education</span>
            </TabsTrigger>
            <TabsTrigger value="skills" className="flex items-center space-x-2">
              <Award className="h-4 w-4" />
              <span>Skills</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Resume Overview</CardTitle>
                <CardDescription>
                  Summary of your resume content and structure
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{sections.length}</div>
                    <div className="text-sm text-muted-foreground">Sections</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{workExperience.length}</div>
                    <div className="text-sm text-muted-foreground">Work Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{skills.length}</div>
                    <div className="text-sm text-muted-foreground">Skills</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Raw Content Preview */}
            <Card>
              <CardHeader>
                <CardTitle>Parsed Content</CardTitle>
                <CardDescription>
                  Original content extracted from your uploaded resume
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg max-h-96 overflow-y-auto">
                  <pre className="text-sm whitespace-pre-wrap">
                    {resume.parsed_content || 'No content available'}
                  </pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sections Tab */}
          <TabsContent value="sections" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Resume Sections</h3>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Section
              </Button>
            </div>
            
            {sections.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No sections found</h3>
                  <p className="text-muted-foreground mb-4">
                    Add sections to organize your resume content
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add First Section
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {sections.map((section) => (
                  <Card key={section.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{section.section_title}</CardTitle>
                          <Badge variant="outline">{section.section_type}</Badge>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Textarea
                        value={section.content}
                        onChange={(e) => {
                          const updatedSections = sections.map(s => 
                            s.id === section.id ? {...s, content: e.target.value} : s
                          )
                          setSections(updatedSections)
                        }}
                        rows={4}
                        placeholder="Section content..."
                      />
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Experience Tab */}
          <TabsContent value="experience" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Work Experience</h3>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Experience
              </Button>
            </div>
            
            {workExperience.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Briefcase className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No work experience found</h3>
                  <p className="text-muted-foreground mb-4">
                    Add your work experience to showcase your professional background
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Experience
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {workExperience.map((exp) => (
                  <Card key={exp.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">
                            {exp.job_title || 'Job Title'}
                          </CardTitle>
                          <CardDescription>
                            {exp.company_name || 'Company Name'}
                          </CardDescription>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Job Title</Label>
                            <Input value={exp.job_title || ''} placeholder="Software Engineer" />
                          </div>
                          <div>
                            <Label>Company</Label>
                            <Input value={exp.company_name || ''} placeholder="Tech Company Inc." />
                          </div>
                        </div>
                        <div>
                          <Label>Description</Label>
                          <Textarea 
                            value={exp.description || ''} 
                            rows={3}
                            placeholder="Describe your role and achievements..."
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Education Tab */}
          <TabsContent value="education" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Education</h3>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Education
              </Button>
            </div>
            
            {education.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <GraduationCap className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No education found</h3>
                  <p className="text-muted-foreground mb-4">
                    Add your educational background and qualifications
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Education
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {education.map((edu) => (
                  <Card key={edu.id}>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold">{edu.degree_type || 'Degree'}</h4>
                            <p className="text-muted-foreground">{edu.institution_name || 'Institution'}</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-sm">{edu.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Skills</h3>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Skill
              </Button>
            </div>
            
            {skills.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No skills found</h3>
                  <p className="text-muted-foreground mb-4">
                    Add your technical and soft skills to highlight your capabilities
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Skill
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {skills.map((skill) => (
                  <Card key={skill.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-semibold">{skill.skill_name}</h4>
                          <Badge variant="outline" className="mt-1">
                            {skill.skill_category || 'General'}
                          </Badge>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default ResumeEditor

